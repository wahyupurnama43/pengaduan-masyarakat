<?php

$host="localhost";

$user="visb3848_visutama";

//$pass="=GP8WrF23Hlu";
$pass="oLL+Om[[z]l6";

mysql_connect($host, $user, $pass)or die ("Database Account tidak dapat di akses....!!!");

mysql_select_db('visb3848_visutama');

?> 



