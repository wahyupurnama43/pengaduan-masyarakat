<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>
        Pengaduan Masyarakat
    </title>
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
    <!-- Nucleo Icons -->
    <link href="<?php echo e(asset('assets/css/nucleo-icons.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/nucleo-svg.css')); ?>" rel="stylesheet" />
    <!-- Font Awesome Icons -->
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
    <link href="<?php echo e(asset('assets/css/nucleo-svg.css')); ?>" rel="stylesheet" />
    <!-- CSS Files -->
    <link id="pagestyle" href="<?php echo e(asset('assets/css/argon-dashboard.css')); ?>" rel="stylesheet" />
    <?php echo $__env->yieldContent('css'); ?>
    <style>
        .navbar-vertical.navbar-expand-xs {
            z-index: 1 !important;
        }
    </style>
    <script src="https://kit.fontawesome.com/58576e20ba.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
</head>

<body class="g-sidenav-show   bg-gray-100">
    <div class="min-height-300 bg-primary position-absolute w-100"></div>
    <?php if (isset($component)) { $__componentOriginal288b082e3ae37093a10c3d78895b4c0d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal288b082e3ae37093a10c3d78895b4c0d = $attributes; } ?>
<?php $component = App\View\Components\SidebarComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sidebar-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\SidebarComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal288b082e3ae37093a10c3d78895b4c0d)): ?>
<?php $attributes = $__attributesOriginal288b082e3ae37093a10c3d78895b4c0d; ?>
<?php unset($__attributesOriginal288b082e3ae37093a10c3d78895b4c0d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal288b082e3ae37093a10c3d78895b4c0d)): ?>
<?php $component = $__componentOriginal288b082e3ae37093a10c3d78895b4c0d; ?>
<?php unset($__componentOriginal288b082e3ae37093a10c3d78895b4c0d); ?>
<?php endif; ?>
    <main class="main-content position-relative border-radius-lg ">
        <!-- Navbar -->
        <?php if (isset($component)) { $__componentOriginal371139be4683378fa30e03f57b6fd258 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal371139be4683378fa30e03f57b6fd258 = $attributes; } ?>
<?php $component = App\View\Components\NavbarComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\NavbarComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal371139be4683378fa30e03f57b6fd258)): ?>
<?php $attributes = $__attributesOriginal371139be4683378fa30e03f57b6fd258; ?>
<?php unset($__attributesOriginal371139be4683378fa30e03f57b6fd258); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal371139be4683378fa30e03f57b6fd258)): ?>
<?php $component = $__componentOriginal371139be4683378fa30e03f57b6fd258; ?>
<?php unset($__componentOriginal371139be4683378fa30e03f57b6fd258); ?>
<?php endif; ?>
        <!-- End Navbar -->
        <div class="container-fluid py-4">
            <?php echo $__env->yieldContent('content'); ?>
            
        </div>
    </main>

    <!--   Core JS Files   -->
    <script src="<?php echo e(asset('assets/js/core/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/core/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/argon-dashboard.min.js')); ?>"></script>
    <?php echo $__env->yieldContent('js'); ?>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    
    <?php if(Session::has('success')): ?>
        <script>
            $(document).ready(function() {
                Toastify({
                    text: "<?php echo e(Session::get('success')); ?>",
                    className: "info",
                    style: {
                        background: "linear-gradient(to right, #9ADE7B, #9ADE7B)",
                    }
                }).showToast();
            });
        </script>
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
        <script>
            $(document).ready(function() {
                Toastify({
                    text: "<?php echo e(Session::get('error')); ?>",
                    className: "error",
                    style: {
                        background: "linear-gradient(to right, #EF4040, #EF4040)",
                    }
                }).showToast();
            });
        </script>
    <?php endif; ?>
</body>

</html>
<?php /**PATH D:\wahyu\laragon\www\pengaduan-masyarakat\resources\views/layouts/master.blade.php ENDPATH**/ ?>