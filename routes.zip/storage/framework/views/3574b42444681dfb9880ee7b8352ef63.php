

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginalfe5e422d9803ad457b814fc982a9048c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe5e422d9803ad457b814fc982a9048c = $attributes; } ?>
<?php $component = App\View\Components\InfoCard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('info-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InfoCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe5e422d9803ad457b814fc982a9048c)): ?>
<?php $attributes = $__attributesOriginalfe5e422d9803ad457b814fc982a9048c; ?>
<?php unset($__attributesOriginalfe5e422d9803ad457b814fc982a9048c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe5e422d9803ad457b814fc982a9048c)): ?>
<?php $component = $__componentOriginalfe5e422d9803ad457b814fc982a9048c; ?>
<?php unset($__componentOriginalfe5e422d9803ad457b814fc982a9048c); ?>
<?php endif; ?>


    <div class="row mt-4">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0 d-flex justify-content-between align-items-center align-content-center">
                    <h6>Data Pengaduan</h6>
                    <?php if(in_array(Auth()->user()->role, ['petugas','masyarakat'])): ?>
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                        Tambah Pengaduan</button>
                    <?php endif; ?>
                </div>
                <div class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive p-0">
                        <table class="table align-items-center mb-0">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Pelapor</th>
                                    <th class = "text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        Aduan
                                    </th>

                                    <th
                                        class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Lokasi</th>
                                    <th
                                        class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Instansi Tujuan</th>

                                    <th
                                        class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Tanggal Pengaduan</th>
                                    
                                    <th
                                        class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Gambar Pengaduan</th>
                                    <th
                                        class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Petugas </th>
                                    <th
                                        class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Status</th>
                                    <th class="text-secondary opacity-7"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $pengaduan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aduan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>

                                        <td>
                                            <div class="d-flex px-2 py-1">
                                                <div class="d-flex flex-column justify-content-center">
                                                    <h6 class="mb-0 text-sm"><?php echo e($aduan->user->nama); ?></h6>
                                                    <p class="text-xs text-secondary mb-0"><?php echo e($aduan->user->email); ?></p>
                                                </div>
                                            </div>
                                        </td>

                                        <td width="100%">
                                            <p class="text-xs font-weight-bold mb-0 text-wrap"><?php echo e($aduan->aduan); ?></p>
                                        </td>

                                        <td class="align-middle text-center">
                                            <span
                                                class="text-secondary text-xs font-weight-bold"><?php echo e($aduan->lokasi); ?></span>
                                        </td>

                                        <td class="align-middle text-center">
                                            <span
                                                class="text-secondary text-xs font-weight-bold"><?php echo e($aduan->intansi_tujuan); ?></span>
                                        </td>

                                        <td class="align-middle text-center">
                                            <span
                                                class="text-secondary text-xs font-weight-bold"><?php echo e(date('d M Y',strtotime($aduan->tgl_aduan))); ?></span>
                                        </td>

                                        <td class="align-middle text-center">
                                            <a href="<?php echo e(asset('images/'.$aduan->gambar_aduan)); ?>" target="_blank">
                                                <img src="<?php echo e(asset('images/'.$aduan->gambar_aduan)); ?>" width="60px" alt="">
                                            </a>
                                        </td>

                                        <td class="align-middle text-center text-sm">
                                            <?php
                                                $status = [];
                                                $statusBadge = '';
                                                $statusText = '';
                                            ?>
                                            <?php $__currentLoopData = $aduan->tanggapan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tanggapan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    if ($tanggapan->status_tanggapan == 'terima') {
                                                        $status[] = 'success';
                                                    } else {
                                                        $status[] = 'danger';
                                                    }
                                                ?>
                                                <span
                                                    class="badge badge-sm cursor-pointer bg-gradient-<?php echo e($tanggapan->status_tanggapan == 'terima' ? 'success' : 'danger'); ?>"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#modalPetugas<?php echo e($tanggapan->id); ?>">
                                                    <?php echo e($tanggapan->user->nama); ?>

                                                </span>
                                                <div class="modal fade" id="modalPetugas<?php echo e($tanggapan->id); ?>" tabindex="-1"
                                                    role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title text-wrap" id="exampleModalLabel">
                                                                    <?php echo e(Str::limit($aduan->aduan, 50, '...')); ?>

                                                                </h5>
                                                                <button type="button" class="btn-close"
                                                                    data-bs-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="mb-3">
                                                                    <select name="status_tanggapan" id=""
                                                                        class="form-control" readonly disabled>
                                                                        <option value="ditolak"
                                                                            <?php echo e(!is_null($tanggapan) && $tanggapan->status_tanggapan == 'ditolak' ? 'selected' : ''); ?>>
                                                                            Di Tolak</option>
                                                                        <option value="terima"
                                                                            <?php echo e(!is_null($tanggapan) && $tanggapan->status_tanggapan == 'terima' ? 'selected' : ''); ?>>
                                                                            Terima</option>
                                                                    </select>
                                                                    <?php $__errorArgs = ['status_tanggapan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <small class="text-danger"><?php echo e($message); ?></small>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>

                                                                <div class="mb-3">
                                                                    <textarea name="tanggapan" class="form-control" id="" cols="30" rows="10" readonly disabled><?php echo e(!is_null($tanggapan) ? $tanggapan->tanggapan : ''); ?></textarea>
                                                                    <?php $__errorArgs = ['tanggapan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <small class="text-danger"><?php echo e($message); ?></small>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>

                                        <?php if(in_array('danger', $status)): ?>
                                            <?php
                                                $statusBadge = 'danger';
                                                $statusText = 'Di Tolak';
                                            ?>
                                        <?php elseif(in_array('success', $status)): ?>
                                            <?php
                                                $statusBadge = 'success';
                                                $statusText = 'Terima';
                                            ?>
                                        <?php else: ?>
                                            <?php
                                                $statusBadge = 'warning';
                                                $statusText = 'Proses';
                                            ?>
                                        <?php endif; ?>

                                        <td class="align-middle text-center">
                                            <span class="badge badge-sm bg-gradient-<?php echo e($statusBadge); ?>">
                                                <?php echo e($statusText); ?>

                                            </span>
                                        </td>

                                        <?php if(in_array(Auth()->user()->role, ['petugas'])): ?>
                                            <?php
                                                $tanggapan = App\Models\Tanggapan::where(['pengaduan_id' => $aduan->id, 'user_id' => Auth::id()])->first();
                                            ?>
                                            <td>
                                                <button class="btn btn-info" data-bs-toggle="modal"
                                                    data-bs-target="#modalVerif<?php echo e($aduan->id); ?>" type="button">
                                                    <i class="fa-solid fa-person-chalkboard"></i>
                                                </button>
                                                <div class="modal fade" id="modalVerif<?php echo e($aduan->id); ?>" tabindex="-1"
                                                    role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                                        <div class="modal-content">
                                                            <form role="form"
                                                                action="<?php echo e(route('tanggapan.store', $aduan->id)); ?>"
                                                                method="post">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="exampleModalLabel">Edit
                                                                    </h5>
                                                                    <button type="button" class="btn-close"
                                                                        data-bs-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <div class="mb-3">
                                                                        <select name="status_tanggapan" id=""
                                                                            class="form-control">
                                                                            <option value="ditolak"
                                                                                <?php echo e(!is_null($tanggapan) && $tanggapan->status_tanggapan == 'ditolak' ? 'selected' : ''); ?>>
                                                                                Di Tolak</option>
                                                                            <option value="terima"
                                                                                <?php echo e(!is_null($tanggapan) && $tanggapan->status_tanggapan == 'terima' ? 'selected' : ''); ?>>
                                                                                Terima</option>
                                                                        </select>
                                                                        <?php $__errorArgs = ['status_tanggapan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <small
                                                                                class="text-danger"><?php echo e($message); ?></small>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>

                                                                    <div class="mb-3">
                                                                        <textarea name="tanggapan" class="form-control" id="" cols="30" rows="10"><?php echo e(!is_null($tanggapan) ? $tanggapan->tanggapan : ''); ?></textarea>
                                                                        <?php $__errorArgs = ['tanggapan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <small
                                                                                class="text-danger"><?php echo e($message); ?></small>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>


                                                                    <div class="text-center">
                                                                        <button type="submit"
                                                                            class="btn bg-gradient-dark w-100 my-4 mb-2">Update
                                                                            Aduan</button>
                                                                    </div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <form action="<?php echo e(route('pengaduan.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Tambah Aduan</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="form-control-label" for="basic-url">Tujuan Aduan</label>
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Tujuan Aduan"
                                    name="tujuan_aduan" aria-label="Tujuan Aduan" aria-describedby="basic-addon1"
                                    required>
                            </div>
                            <?php $__errorArgs = ['tujuan_aduan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label class="form-control-label" for="basic-url">Tanggal Aduan</label>
                            <div class="input-group">
                                <input type="date" class="form-control" name="tgl_aduan" aria-label="Tujuan Aduan"
                                    aria-describedby="basic-addon1" required>
                            </div>

                            <?php $__errorArgs = ['tgl_aduan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label class="form-control-label" for="basic-url">Lokasi Masalah</label>
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Lokasi Masalah" name="lokasi"
                                    aria-label="Lokasi Masalah" aria-describedby="basic-addon1" required>
                            </div>

                            <?php $__errorArgs = ['lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label class="form-control-label" for="basic-url">Foto/Gambar Aduan</label>
                            <div class="input-group">
                                <input type="file" class="form-control" name="gambar_aduan" aria-label="Tujuan Aduan"
                                    aria-describedby="basic-addon1" required>
                            </div>

                            <?php $__errorArgs = ['gambar_aduan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label class="form-control-label" for="basic-url">Aduan</label>
                            <div class="input-group">
                                <textarea name="aduan" class="form-control" id="" cols="30" rows="10" required></textarea>
                            </div>

                            <?php $__errorArgs = ['aduan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn bg-gradient-primary">Save changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wahyu\laragon\www\pengaduan-masyarakat\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>